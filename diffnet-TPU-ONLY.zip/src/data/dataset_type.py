from enum import Enum


class DatasetType(Enum):
    Train = "train"
    Test = "test"
    Validation = "validation"
