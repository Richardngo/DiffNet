from enum import Enum


class KeyType(Enum):
    USER = "user"
    ITEM = "item"
