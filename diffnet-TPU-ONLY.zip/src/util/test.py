import logging

logger = logging.getLogger(__name__)


def test_logger():
    logger.debug("Test function")
