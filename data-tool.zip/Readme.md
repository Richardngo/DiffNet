# Steps by step

1. generate_datasets.py (update constant values)
2. generate_mappings.py
3. generate_embeddings.py (after getting embeddings from google collab notebook)
4. ratings.py
5.
